// ============================================================
// MobEleView Extended - Patch fuer src/map/clif.cpp
// [Hyroshima / Extended]
//
// FEHLER-FIX gegenueber MobEleView_A.diff:
//   - Schreibt in packet.groupId / packet.title direkt (NICHT md->ud)
//   - md->ud bleibt unveraendert -> kein globaler Mob-State-Schaden
//   - Buffer 64 Bytes statt NAME_LENGTH -> kein Overflow bei Modus 6
//   - Korrekte Verwendung von safestrncpy zum finalen Kopieren
//
// ============================================================
// SCHRITT 1 - Falls MobEleView_A.diff bereits angewendet wurde:
//   Suche nach:  // Show Element Info [Hyroshima]
//   Entferne den gesamten Block:
//     - Die Variablen-Deklarationen: ele_group, ele_name, output
//     - Den if(battle_config.mob_ele_view) { ... } Block
//   Lasse den originalen "if (ud != nullptr)" Block ZUNAECHST stehen,
//   ersetze ihn dann gemaess Schritt 2.
//
// ============================================================
// SCHRITT 2 - Wo in clif.cpp suchen:
//
//   Suche in der Funktion clif_name() nach diesem Abschnitt
//   (befindet sich im BL_MOB-Case, ca. Zeile 10176 in vanilla rAthena):
//
//     #if PACKETVER_MAIN_NUM >= 20180207 || PACKETVER_RE_NUM >= 20171129 || PACKETVER_ZERO_NUM >= 20171130
//             unit_data *ud = unit_bl2ud(bl);
//
//             if (ud != nullptr) {
//                 memcpy(packet.title, ud->title, NAME_LENGTH);
//                 packet.groupId = ud->group_id;
//             }
//     #endif
//
// ============================================================
// SCHRITT 3 - NUR den if(ud != nullptr){...} Block ersetzen:
//   Die #if / #endif Zeilen BLEIBEN unveraendert!
//   Ersetze nur den Block zwischen diesen Zeilen durch folgenden Code:
// ============================================================

				if (ud != nullptr) {
					memcpy(packet.title, ud->title, NAME_LENGTH);
					packet.groupId = ud->group_id;

					// -------------------------------------------------------
					// Mob Element/Race View [Hyroshima/Extended]
					// Schreibt ausschliesslich in packet-Felder (NICHT in md->ud).
					// Per-Spieler-Modus hat Prioritaet vor globalem Config-Wert.
					// -------------------------------------------------------
					{
						int display_mode = 0;
						map_session_data *src_sd = BL_CAST(BL_PC, src);

						if (src_sd != nullptr && src_sd->mob_ele_view_mode > 0)
							display_mode = (int)src_sd->mob_ele_view_mode;
						else if (battle_config.mob_ele_view > 0)
							display_mode = battle_config.mob_ele_view;

						if (display_mode > 0) {
							// Element-Namen (Index = md->status.def_ele, Werte 0-9)
							static const char* const ele_names[10] = {
								"Neutral", "Water", "Earth",  "Fire", "Wind",
								"Poison",  "Holy",  "Shadow", "Ghost", "Undead"
							};
							// Client-Sprite groupId fuer das Element-Icon
							// Muss mit den BMP-Dateien in
							//   data/texture/유저인터페이스/group/
							// uebereinstimmen.
							static const int ele_grp_ids[10] = {
								51, 52, 53, 54, 55, 59, 57, 58, 59, 60
							};
							// Race-Namen (Index = RC_*-Enum, Werte 0-9)
							static const char* const race_names[10] = {
								"Formless", "Undead", "Brute",    "Plant",  "Insect",
								"Fish",     "Demon",  "DemiHuman","Angel",  "Dragon"
							};

							int ele  = (int)md->status.def_ele;
							int elvl = (int)md->status.ele_lv;
							int race = (int)md->status.race;

							const char* ele_name  = (ele  >= 0 && ele  < 10) ? ele_names[ele]  : "?";
							const char* race_name = (race >= 0 && race < 10) ? race_names[race] : "?";
							int grp_id            = (ele  >= 0 && ele  < 10) ? ele_grp_ids[ele] : -1;

							// 64-Byte-Puffer verhindert Buffer-Overflow bei Modus 6
							// (laengster String: "Neutral Lv.4 | DemiHuman" = 24 Zeichen)
							char new_title[64] = {0};

							switch (display_mode) {
								case 1: // Nur Icon - kein Titel-Text
									break;
								case 2: // Element-Name
									safesnprintf(new_title, sizeof(new_title),
										"%s", ele_name);
									break;
								case 3: // Element-Name + Level
									safesnprintf(new_title, sizeof(new_title),
										"%s Lv.%d", ele_name, elvl);
									break;
								case 4: // Nur Race - kein Icon-Override
									safesnprintf(new_title, sizeof(new_title),
										"%s", race_name);
									grp_id = -1;
									break;
								case 5: // Element + Race
									safesnprintf(new_title, sizeof(new_title),
										"%s | %s", ele_name, race_name);
									break;
								case 6: // Alles
									safesnprintf(new_title, sizeof(new_title),
										"%s Lv.%d | %s", ele_name, elvl, race_name);
									break;
							}

							// In Paket schreiben (nie in md->ud!)
							if (grp_id > -1)
								packet.groupId = grp_id;
							if (new_title[0] != '\0')
								safestrncpy(packet.title, new_title, NAME_LENGTH);
						}
					}
					// -------------------------------------------------------
				}

// ============================================================
// SCHRITT 4 - pc.hpp manuell bearbeiten:
//
//   Datei oeffnen: src/map/pc.hpp
//   In der map_session_data Struktur nach folgendem suchen:
//
//       char fakename[NAME_LENGTH];
//
//   DIREKT DANACH diese Zeile einfuegen:
//
//       uint8 mob_ele_view_mode; ///< 0=Server-Default, 1-6=Spieler-Override (@mobeleview)
//
//   Falls fakename nicht vorhanden ist: Die Zeile bei einem anderen
//   uint8-Feld in map_session_data einfuegen.
//   Der Wert wird beim Session-Start automatisch auf 0 initialisiert.
// ============================================================
